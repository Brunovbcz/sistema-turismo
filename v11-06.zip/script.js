const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

//Function to load html pages
function loadHTML(url, fn, targetId = 'html') {
  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
      return res.text();
    })
    .then(html => {
      document.querySelector(targetId).innerHTML = html;
      if (fn) fn()
    })
    .catch(err => {
      console.error(err);
      document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
    });
}

function mainHeader(){
  const menuBtn = document.querySelector('#menu-btn');
  const leaveBtn = document.getElementById("leave-btn");
  const sideMenu = document.querySelector('.side-menu');
  const clientsBtn = document.querySelector('#clients');
  const dashBtn = document.querySelector('#dashboard');
  const employBtn = document.querySelector('#employes');
  const soldBtn = document.querySelector('#solds');
  const packsBtn = document.querySelector('#pack');

  const exitModal = document.querySelector('.exit-modal');

  leaveBtn.addEventListener("click", () => {
      exitModal.classList.add('visible');

      const cancel = exitModal.querySelector('#cancel');
      const confirm = exitModal.querySelector('#confirm');

      cancel.addEventListener('click', () => {
        exitModal.classList.remove('visible');
      })

      confirm.addEventListener('click', () => {
        exitModal.classList.remove('visible')
        loadHTML('../pages/index.html')
        window.location.reload();
      })
  });

  menuBtn.addEventListener('click', () => {
      sideMenu.classList.toggle('visible');
      menuBtn.classList.toggle('opened');
  })

  clientsBtn.addEventListener('click', () => {
    loadHTML('../pages/clientes.html', mainClients)
  })

  dashBtn.addEventListener('click', () => {
    loadHTML('../pages/dashboard.html', mainDashboard)
  })

  employBtn.addEventListener('click', () => {
    loadHTML('../pages/funcionarios.html', mainEmployes)
  })

  soldBtn.addEventListener('click', () => {
    loadHTML('../pages/vendas.html', mainSolds)
  })

  packsBtn.addEventListener('click', () => {
    loadHTML('../pages/pacotes.html', mainPacotes)
  })
}

function registrar(name, date, cpf, tel, email, tbody){
  let nameTh = document.createElement('th');
  let dateTh = document.createElement('th');
  let cpfTh = document.createElement('th');
  let telTh = document.createElement('th');
  let emailTh = document.createElement('th');

  nameTh.textContent = name;
  dateTh.textContent = date;
  cpfTh.textContent = cpf;
  telTh.textContent = tel;
  emailTh.textContent = email;

  let tr = document.createElement('tr');

  tr.appendChild(nameTh);
  tr.appendChild(dateTh);
  tr.appendChild(cpfTh);
  tr.appendChild(telTh);
  tr.appendChild(emailTh);

  tbody.appendChild(tr);
}

function mainEmployes(){
  mainHeader()
  let employTbody = document.querySelector('tbody');
  
  function registros(){
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);

  }registros();
}

function mainSolds(){
  mainHeader()
}

function mainClients(){
  mainHeader()
}

function mainPacotes(){
  mainHeader()
}

function mainDashboard(){
    mainHeader()

  document.getElementById("vendas-7d").innerText = "R$ 0,00";
  document.getElementById("vendas-30d").innerText = "R$ 0,00";
  document.getElementById("clientes").innerText = "0";
}

form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})