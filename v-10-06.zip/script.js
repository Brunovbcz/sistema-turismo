const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

//Function to load html pages
function loadHTML(url, fn, targetId = 'html') {
  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
      return res.text();
    })
    .then(html => {
      document.querySelector(targetId).innerHTML = html;
      if (fn) fn()
    })
    .catch(err => {
      console.error(err);
      document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
    });
}

function mainHeader(){
  const menuBtn = document.querySelector('#menu-btn');
    const leaveBtn = document.getElementById("leave-btn");
    const sideMenu = document.querySelector('.side-menu');
    const clientsBtn = document.querySelector('#clients');
    const dashBtn = document.querySelector('#dashboard');

    const exitModal = document.querySelector('.exit-modal');

    leaveBtn.addEventListener("click", () => {
        exitModal.classList.add('visible');

        const cancel = exitModal.querySelector('#cancel');
        const confirm = exitModal.querySelector('#confirm');

        cancel.addEventListener('click', () => {
          exitModal.classList.remove('visible');
        })

        confirm.addEventListener('click', () => {
          exitModal.classList.remove('visible')
          loadHTML('../pages/index.html')
          window.location.reload();
        })
    });

    menuBtn.addEventListener('click', () => {
        sideMenu.classList.toggle('visible');
        menuBtn.classList.toggle('opened');
    })

    clientsBtn.addEventListener('click', () => {
      loadHTML('../pages/clientes.html', mainClients)
    })

    dashBtn.addEventListener('click', () => {
      loadHTML('../pages/dashboard.html', mainDashboard)
    })
}

function mainClients(){
  mainHeader()
  
  // Sample client data (in a real app, this would come from a database)
        let clients = [
            { name: "João Silva", email: "joao.silva@email.com", phone: "(11) 99999-9999" },
            { name: "Maria Oliveira", email: "maria.oli@email.com", phone: "(21) 88888-8888" }
        ];

        // Function to display clients
        function displayClients(clientArray) {
            const clientsList = document.getElementById('clients-list');
            clientsList.innerHTML = '';
            clientArray.forEach(client => {
                const clientItem = document.createElement('div');
                clientItem.className = 'client-item';
                clientItem.innerHTML = `
                    <span>${client.name} - ${client.email} - ${client.phone}</span>
                `;
                clientsList.appendChild(clientItem);
            });
        }

        // Function to search clients
        function searchClients() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const filteredClients = clients.filter(client => 
                client.name.toLowerCase().includes(searchTerm) ||
                client.email.toLowerCase().includes(searchTerm) ||
                client.phone.includes(searchTerm)
            );
            displayClients(filteredClients);
        }

        // Function to register a new client
        function registerClient() {
            const name = document.getElementById('client-name').value;
            const email = document.getElementById('client-email').value;
            const phone = document.getElementById('client-phone').value;

            if (name && email && phone) {
                clients.push({ name, email, phone });
                displayClients(clients);
                // Clear form
                document.getElementById('client-name').value = '';
                document.getElementById('client-email').value = '';
                document.getElementById('client-phone').value = '';
                alert('Cliente cadastrado com sucesso!');
            } else {
                alert('Por favor, preencha todos os campos!');
            }
        }

        // Initial display of clients
        displayClients(clients);

        // Search on Enter key
        document.getElementById('search-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchClients();
            }
        });
}

function mainDashboard(){
    mainHeader()

  document.getElementById("vendas-7d").innerText = "R$ 2.400,00";
  document.getElementById("vendas-30d").innerText = "R$ 12.000,00";
  document.getElementById("clientes").innerText = "0";
}

form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})