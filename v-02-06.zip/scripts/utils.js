function loadHTML(url, targetId = 'conteudo') {
    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
        return res.text();
      })
      .then(html => {
        document.getElementById(targetId).innerHTML = html;
      })
      .catch(err => {
        console.error(err);
        document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
      });
  }
  