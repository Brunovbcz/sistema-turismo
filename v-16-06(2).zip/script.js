const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

//Global Values
let clientsNumber = 0;
let vendasQuant = 0;

let nomeClientes = [];
let pacotes = [];

//Function to load html pages
function loadHTML(url, fn, targetId = 'html') {
  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
      return res.text();
    })
    .then(html => {
      document.querySelector(targetId).innerHTML = html;
      if (fn) fn()
    })
    .catch(err => {
      console.error(err);
      document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
    });
}

function mainHeader(){
  const menuBtn = document.querySelector('#menu-btn');
  const leaveBtn = document.getElementById("leave-btn");
  const sideMenu = document.querySelector('.side-menu');
  const clientsBtn = document.querySelector('#clients');
  const dashBtn = document.querySelector('#dashboard');
  const soldBtn = document.querySelector('#solds');
  const packsBtn = document.querySelector('#pack');

  const exitModal = document.querySelector('.exit-modal');

  leaveBtn.addEventListener("click", () => {
      exitModal.classList.add('visible');

      const cancel = exitModal.querySelector('#cancel');
      const confirm = exitModal.querySelector('#confirm');

      cancel.addEventListener('click', () => {
        exitModal.classList.remove('visible');
      })

      confirm.addEventListener('click', () => {
        exitModal.classList.remove('visible')
        loadHTML('../pages/index.html')
        window.location.reload();
      })
  });

  menuBtn.addEventListener('click', () => {
      sideMenu.classList.toggle('visible');
      menuBtn.classList.toggle('opened');
  })

  clientsBtn.addEventListener('click', () => {
    loadHTML('../pages/clientes.html', mainClients)
  })

  dashBtn.addEventListener('click', () => {
    loadHTML('../pages/dashboard.html', mainDashboard)
  })

  soldBtn.addEventListener('click', () => {
    loadHTML('../pages/pacotes.html', mainPacotes)
    loadHTML('../pages/vendas.html', mainSolds)
  })

  packsBtn.addEventListener('click', () => {
    loadHTML('../pages/pacotes.html', mainPacotes)
  })
}

function registrar(name, date, cpf, tel, email, tbody){
  let nameTh = document.createElement('th');
  let dateTh = document.createElement('th');
  let cpfTh = document.createElement('th');
  let telTh = document.createElement('th');
  let emailTh = document.createElement('th');

  nameTh.textContent = name;
  dateTh.textContent = date;
  cpfTh.textContent = cpf;
  telTh.textContent = tel;
  emailTh.textContent = email;

  let tr = document.createElement('tr');

  tr.appendChild(nameTh);
  tr.appendChild(dateTh);
  tr.appendChild(cpfTh);
  tr.appendChild(telTh);
  tr.appendChild(emailTh);

  tbody.appendChild(tr);
}

function mainSolds(){
  mainHeader();

  const newSoldBtn = document.querySelector('#cad');
  const newSoldPage = document.querySelector('.background-parent');
  const tbody = document.querySelector('tbody');
  const searchIn = document.querySelector('.search').querySelector('input');

  exibirVendasSalvas(tbody)

  newSoldBtn.addEventListener('click', () => {
    newSoldPage.classList.add('visible');

    const cancel = newSoldPage.querySelector('#cancel');
    const form = newSoldPage.querySelector('form');
    const clientIn = newSoldPage.querySelector('#client');
    const priceIn = newSoldPage.querySelector('#price');
    const packIn = newSoldPage.querySelector('#packSelect');
    const dateIn = newSoldPage.querySelector('#date');
    const payIn = newSoldPage.querySelector('#payment');
    const arr = JSON.parse(localStorage.getItem('nomeClientes')) || [];
    console.log(arr)
    arr.forEach(nome => {
      const existe = Array.from(clientIn.options).some(opt => opt.value === nome);

      if (!existe) {
        const option = document.createElement('option');
        option.value = nome;
        option.textContent = nome;
        clientIn.appendChild(option);
      }
    });

    pacotes.forEach(pack => {
      const option = document.createElement('option');
      option.value = pack.querySelector('h2').textContent;
      option.textContent = pack.querySelector('h2').textContent;
      packIn.appendChild(option);
    });

    packIn.addEventListener('change', (e) => {
      const selectedPack = pacotes.find(pack => pack.querySelector('h2').textContent === e.target.value);
      if (selectedPack) {
        let price = selectedPack.querySelector('p').textContent.match(/R\$ ([\d,.]+)/);
        if (price) {
          priceIn.value = price[0];
        } else {
          priceIn.value = '';
        }
      } else {
        priceIn.value = '';
      }
    });

    function handleSubmit(e) {
      e.preventDefault();
      cadastrarPage.classList.remove('visible');

      const venda = {
        client: clientIn.value,
        price: priceIn.value,
        pack: packIn.value,
        date: dateIn.value,
        pay: payIn.value
      };

      salvarVenda(venda)
      adicionarVendaNaTabela(venda, tbody)

      form.removeEventListener('submit', handleSubmit);
      form.reset();
    }

    cancel.addEventListener('click', () => {  
      form.removeEventListener('submit', handleSubmit);
      newSoldPage.classList.remove('visible');
    });

    form.addEventListener('submit', handleSubmit);
  })

  searchIn.addEventListener('input', () => {
    const filtro = searchIn.value.toLowerCase();
    const linhas = tbody.querySelectorAll('tr');

    linhas.forEach(linha => {
      const nomeCliente = linha.querySelector('td')?.textContent.toLowerCase();

      if (nomeCliente.includes(filtro)) {
        linha.style.display = '';
      } else {
        linha.style.display = 'none';
      }
    });
  })

  function adicionarVendaNaTabela(venda, tbody){
    const row = document.createElement('tr');

    row.innerHTML = `
    <td>${venda.cliente}</td>
    <td>${venda.valor}</td>
    <td>${venda.pacote}</td>
    <td>${venda.data}</td>
    <td>${venda.pagamento}</td>
    `;

    const excludeBtn = document.createElement('button');
    excludeBtn.textContent = '❌';
    row.appendChild(excludeBtn);
    excludeBtn.style.backgroundColor = 'transparent';
    excludeBtn.style.border = 'none';
    excludeBtn.style.cursor = 'pointer';

    excludeBtn.addEventListener('click', () => {
      if (confirm('Deseja excluir essa venda?')) {
        row.remove();
        let vendas = JSON.parse(localStorage.getItem('vendas')) || [];
        vendas = venda.filter(v => v.cliente !== venda.cliente || v.preco !== venda.preco);
        localStorage.setItem('vendas', JSON.stringify(vendas));
        vendasQuant--;
        localStorage.setItem('vendasQuant', JSON.stringify(vendasQuant));
      }
    });

    tbody.appendChild(row)
  }

  function salvarVenda(venda){
    const vendas = JSON.parse(localStorage.getItem('vendas')) || [];
    vendas.push(venda);
    localStorage.setItem('vendas', JSON.stringify(vendas));
    vendasQuant += venda.price.value;
    localStorage.setItem('vendasQuant', JSON.stringify(vendasQuant));
  }

  function exibirVendasSalvas(tbody){
    let vendas = JSON.parse(localStorage.getItem('vendas')) || [];
    vendas.forEach(venda => {
      adicionarVendaNaTabela(venda, tbody);
    })
  }
}

function mainClients() {
  mainHeader();
  const cadastrarBtn = document.querySelector('#cad');
  const cadastrarPage = document.querySelector('.background-parent');
  const tbody = document.querySelector('tbody');
  const searchIn = document.querySelector('.search').querySelector('input');

  exibirClientesSalvos(tbody);

  cadastrarBtn.addEventListener('click', () => {
    cadastrarPage.classList.add('visible');
    const cancel = cadastrarPage.querySelector('#cancel');
    const form = cadastrarPage.querySelector('form');
    const nameIn = cadastrarPage.querySelector('#name');
    const dateIn = cadastrarPage.querySelector('#date');
    const cpfIn = cadastrarPage.querySelector('#cpf');
    const telIn = cadastrarPage.querySelector('#tel');
    const emailIn = cadastrarPage.querySelector('#email');

    function handleSubmit(e) {
      e.preventDefault();
      cadastrarPage.classList.remove('visible');

      const cliente = {
        nome: nameIn.value,
        nascimento: dateIn.value,
        cpf: cpfIn.value,
        telefone: telIn.value,
        email: emailIn.value
      };

      let vrr = JSON.parse(localStorage.getItem('nomeClientes')) || [];
      vrr.push(cliente.nome);
      localStorage.setItem('nomeClientes', JSON.stringify(vrr));

      salvarCliente(cliente);
      adicionarClienteNaTabela(cliente, tbody);

      form.removeEventListener('submit', handleSubmit);
      form.reset();
    }

    cpfIn.addEventListener('input', () => {
      let value = cpfIn.value.replace(/\D/g, '');
      value = value.slice(0, 11);
      if (value.length > 9) {
        value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
      } else if (value.length > 6) {
        value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
      } else if (value.length > 3) {
        value = value.replace(/(\d{3})(\d{1,3})/, '$1.$2');
      }
      cpfIn.value = value;
    });

    telIn.addEventListener('input', () => {
      let value = telIn.value.replace(/\D/g, '');
      value = value.slice(0, 11);
      if (value.length > 10) {
        value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
      } else if (value.length > 6) {
        value = value.replace(/(\d{2})(\d{4})(\d{1,4})/, '($1) $2-$3');
      } else if (value.length > 2) {
        value = value.replace(/(\d{2})(\d{1,5})/, '($1) $2');
      } else {
        value = value.replace(/(\d{0,2})/, '($1');
      }
      telIn.value = value;
    });

    cancel.addEventListener('click', () => {
      form.removeEventListener('submit', handleSubmit);
      cadastrarPage.classList.remove('visible');
    });

    form.addEventListener('submit', handleSubmit);
  });

  searchIn.addEventListener('input', () => {
    const filtro = searchIn.value.toLowerCase();
    const linhas = tbody.querySelectorAll('tr');

    linhas.forEach(linha => {
      const nomeCliente = linha.querySelector('td')?.textContent.toLowerCase();

      if (nomeCliente.includes(filtro)) {
        linha.style.display = '';
      } else {
        linha.style.display = 'none';
      }
    });
  })
}

function salvarCliente(cliente) {
  const clientes = JSON.parse(localStorage.getItem('clientes')) || [];
  clientes.push(cliente);
  localStorage.setItem('clientes', JSON.stringify(clientes));
  clientsNumber ++
  localStorage.setItem('quantidadeClientes', JSON.stringify(clientsNumber))
}

function exibirClientesSalvos(tbody) {
  let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
  clientes.forEach(cliente => {
    adicionarClienteNaTabela(cliente, tbody);
  });
}

function editClient(cliente, row, tbody) {
  const cadastrarPage = document.querySelector('.background-parent');
  const form = cadastrarPage.querySelector('form');
  const nameIn = cadastrarPage.querySelector('#name');
  const dateIn = cadastrarPage.querySelector('#date');
  const cpfIn = cadastrarPage.querySelector('#cpf');
  const telIn = cadastrarPage.querySelector('#tel');
  const emailIn = cadastrarPage.querySelector('#email');
  const cancel = cadastrarPage.querySelector('#cancel');

  nameIn.value = cliente.nome;
  dateIn.value = cliente.nascimento;
  cpfIn.value = cliente.cpf;
  telIn.value = cliente.telefone;
  emailIn.value = cliente.email;

  cadastrarPage.classList.add('visible');

  function handleEditSubmit(e) {
    e.preventDefault();

    const updatedClient = {
      nome: nameIn.value,
      nascimento: dateIn.value,
      cpf: cpfIn.value,
      telefone: telIn.value,
      email: emailIn.value
    };

    let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
    clientes = clientes.map(c => 
      c.cpf === cliente.cpf && c.nome === cliente.nome ? updatedClient : c
    );
    localStorage.setItem('clientes', JSON.stringify(clientes));

    row.innerHTML = `
      <td>${updatedClient.nome}</td>
      <td>${updatedClient.nascimento}</td>
      <td>${updatedClient.cpf}</td>
      <td>${updatedClient.telefone}</td>
      <td>${updatedClient.email}</td>
    `;

    const excludeBtn = document.createElement('button');
    excludeBtn.textContent = '❌';
    excludeBtn.style.backgroundColor = 'transparent';
    excludeBtn.style.border = 'none';
    excludeBtn.style.cursor = 'pointer';
    row.appendChild(excludeBtn);

    const newEditBtn = document.createElement('button');
    newEditBtn.textContent = '✏️';
    newEditBtn.style.backgroundColor = 'transparent';
    newEditBtn.style.border = 'none';
    newEditBtn.style.cursor = 'pointer';
    row.appendChild(newEditBtn);

    excludeBtn.addEventListener('click', () => {
      if (confirm(`Deseja excluir o cliente ${updatedClient.nome}?`)) {
        row.remove();
        let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
        let nomeClientes = JSON.parse(localStorage.getItem('nomeClientes')) || [];
        nomeClientes = nomeClientes.filter(nome => nome !== updatedClient.nome);
        console.log(nomeClientes);
        clientes = clientes.filter(c => c.nome !== updatedClient.nome || c.cpf !== updatedClient.cpf);
        localStorage.setItem('clientes', JSON.stringify(clientes));
        clientsNumber--;
        localStorage.setItem('quantidadeClientes', JSON.stringify(clientsNumber));
        localStorage.setItem('nomeClientes', JSON.stringify(nomeClientes));
      }
    });

    newEditBtn.addEventListener('click', () => {
      editClient(updatedClient, row, tbody);
    });

    cadastrarPage.classList.remove('visible');
    form.removeEventListener('submit', handleEditSubmit);
    form.reset();
  }

  cancel.addEventListener('click', () => {
    form.removeEventListener('submit', handleEditSubmit);
    cadastrarPage.classList.remove('visible');
    form.reset();
  });

  cpfIn.addEventListener('input', () => {
    let value = cpfIn.value.replace(/\D/g, '');
    value = value.slice(0, 11);
    if (value.length > 9) {
      value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
    } else if (value.length > 6) {
      value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
    } else if (value.length > 3) {
      value = value.replace(/(\d{3})(\d{1,3})/, '$1.$2');
    }
    cpfIn.value = value;
  });

  telIn.addEventListener('input', () => {
    let value = telIn.value.replace(/\D/g, '');
    value = value.slice(0, 11);
    if (value.length > 10) {
      value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    } else if (value.length > 6) {
      value = value.replace(/(\d{2})(\d{4})(\d{1,4})/, '($1) $2-$3');
    } else if (value.length > 2) {
      value = value.replace(/(\d{2})(\d{1,5})/, '($1) $2');
    } else {
      value = value.replace(/(\d{0,2})/, '($1');
    }
    telIn.value = value;
  });

  form.addEventListener('submit', handleEditSubmit);
}

function adicionarClienteNaTabela(cliente, tbody) {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${cliente.nome}</td>
    <td>${cliente.nascimento}</td>
    <td>${cliente.cpf}</td>
    <td>${cliente.telefone}</td>
    <td>${cliente.email}</td>
  `;

  const excludeBtn = document.createElement('button');
  excludeBtn.textContent = '❌';
  row.appendChild(excludeBtn);
  excludeBtn.style.backgroundColor = 'transparent';
  excludeBtn.style.border = 'none';
  excludeBtn.style.cursor = 'pointer';

  const editBtn = document.createElement('button');
  editBtn.textContent = '✏️';
  row.appendChild(editBtn);
  editBtn.style.backgroundColor = 'transparent';
  editBtn.style.border = 'none';
  editBtn.style.cursor = 'pointer';
  
  excludeBtn.addEventListener('click', () => {
    if (confirm(`Deseja excluir o cliente ${cliente.nome}?`)) {
      row.remove();
      let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
      clientes = clientes.filter(c => c.nome !== cliente.nome || c.cpf !== cliente.cpf);
      localStorage.setItem('clientes', JSON.stringify(clientes));
      clientsNumber--;
      localStorage.setItem('quantidadeClientes', JSON.stringify(clientsNumber));
      nomeClientes.splice(nomeClientes.indexOf(cliente.nome), 1);
      localStorage.setItem('nomeClientes', JSON.stringify(nomeClientes));
    }
  });

  editBtn.addEventListener('click', () => {
    editClient(cliente, row, tbody);
  });

  tbody.appendChild(row);
}

function mainPacotes(){
  mainHeader();

  const btnNovoPacote = document.getElementById('cad');
  const btnExcluir = document.getElementById('ex');
  const modal = document.getElementById('new-package-modal');
  const overlay = document.getElementById('overlay');
  const btnCancelar = document.getElementById('cancel-btn');
  const btnConfirmar = document.getElementById('confirm-btn');

  const inputNome = document.getElementById('local-name');
  const inputImagem = document.getElementById('image-link');
  const inputDescricao = document.getElementById('description');
  const inputPreco = document.getElementById('price');

  const packsParent = document.querySelector('.packs-parent');

  const deleteListModal = document.getElementById('delete-list-modal');
  const deletePackList = document.getElementById('delete-pack-list');
  const btnCloseDeleteList = document.getElementById('btn-close-delete-list');

  const confirmDeleteModal = document.getElementById('confirm-delete-modal');
  const btnCancelDelete = document.getElementById('cancel-delete-btn');
  const btnConfirmDelete = document.getElementById('confirm-delete-btn');

  let pacoteSelecionado = null;

  document.querySelectorAll('.pack-container').forEach(pack => {
  const nome = pack.querySelector('h2')?.textContent.trim();

  const jaExiste = pacotes.some(p => {
    const nomeExistente = p.querySelector('h2')?.textContent.trim();
    return nomeExistente === nome;
  });

  if (!jaExiste) {
    pacotes.push(pack);
  }
});

  function openModal(modalElement) {
    modalElement.classList.remove('hidden');
    overlay.classList.remove('hidden');
  }
  function closeModal(modalElement) {
    modalElement.classList.add('hidden');
    overlay.classList.add('hidden');
  }

  btnNovoPacote.addEventListener('click', () => {
    openModal(modal);
    inputNome.value = '';
    inputImagem.value = '';
    inputDescricao.value = '';
    inputPreco.value = '';
  });

  btnCancelar.addEventListener('click', () => closeModal(modal));
  overlay.addEventListener('click', () => {
    closeModal(modal);
    closeModal(deleteListModal);
    closeModal(confirmDeleteModal);
  });

  btnConfirmar.addEventListener('click', () => {
    const nome = inputNome.value.trim();
    const imagem = inputImagem.value.trim();
    const descricao = inputDescricao.value.trim();
    const preco = inputPreco.value.trim();

    if (!nome || !imagem || !descricao || !preco) {
      return;
    }
    if (isNaN(preco) || Number(preco) < 0) {
      return;
    }

    const novoPack = document.createElement('div');
    novoPack.classList.add('pack-container');

    novoPack.innerHTML = `
      <img src="${imagem}" alt="Imagem de ${nome}" onerror="this.src='https://via.placeholder.com/450x280?text=Imagem+inválida'">
      <h2>${nome}</h2>
      <p><strong>Custo (individual):</strong> R$ ${Number(preco).toFixed(2)}</p>
      <p><strong>Descrição: </strong>${descricao}</p>
    `;

    packsParent.appendChild(novoPack);
    closeModal(modal);
  });

  btnExcluir.addEventListener('click', () => {
    deletePackList.innerHTML = '';

    const pacotes = packsParent.querySelectorAll('.pack-container');
    if(pacotes.length === 0){
      alert("Não há pacotes para excluir.");
      return;
    }

    pacotes.forEach((pack) => {
      const nomePacote = pack.querySelector('h2').textContent;
      const li = document.createElement('li');
      li.textContent = nomePacote;
      li.style.cursor = 'pointer';
      li.style.padding = '8px 12px';
      li.style.borderBottom = '1px solid #ccc';

      li.addEventListener('click', () => {
        pacoteSelecionado = pack;
        closeModal(deleteListModal);
        openModal(confirmDeleteModal);
      });

      deletePackList.appendChild(li);
    });

    openModal(deleteListModal);
  });

  btnCloseDeleteList.addEventListener('click', () => {
    closeModal(deleteListModal);
  });

  btnCancelDelete.addEventListener('click', () => {
    closeModal(confirmDeleteModal);
    pacoteSelecionado = null;
  });

  btnConfirmDelete.addEventListener('click', () => {
    if(pacoteSelecionado){
      packsParent.removeChild(pacoteSelecionado);
      pacoteSelecionado = null;
    }
    closeModal(confirmDeleteModal);
  });
}

function mainDashboard(){
    mainHeader()

  clientsNumber = localStorage.getItem('quantidadeClientes');
  if (clientsNumber === 'undefined') clientsNumber = 0;
  document.getElementById("vendas-7d").innerText = "R$ 0,00";
  document.getElementById("vendas-30d").innerText = "R$ 0,00";
  document.getElementById("clientes").innerText = clientsNumber;
}

form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})