const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

function mainDashboard(){
    const menuBtn = document.querySelector('#menu-btn');
    const leaveBtn = document.getElementById("leave-btn");
    const sideMenu = document.querySelector('.side-menu');

    leaveBtn.addEventListener("click", () => {
        modal.classList.remove("hidden");
        setupExitModal();
    });

    menuBtn.addEventListener('click', () => {
        sideMenu.classList.toggle('visible');
    })
}

function loadHTML(url, fn, targetId = 'html') {
    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
        return res.text();
      })
      .then(html => {
        document.querySelector(targetId).innerHTML = html;
        fn()
      })
      .catch(err => {
        console.error(err);
        document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
      });
  }


form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})

function setupExitModal() {
  const modal = document.getElementById("confirm-exit-modal");
  const cancelExit = document.getElementById("cancel-exit");
  const confirmExit = document.getElementById("confirm-exit");

  cancelExit.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  confirmExit.addEventListener("click", () => {
    location.reload();
  });
}