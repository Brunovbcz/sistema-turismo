const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

//Function to load html pages
function loadHTML(url, fn, targetId = 'html') {
  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
      return res.text();
    })
    .then(html => {
      document.querySelector(targetId).innerHTML = html;
      if (fn) fn()
    })
    .catch(err => {
      console.error(err);
      document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
    });
}

function mainDashboard(){
    const menuBtn = document.querySelector('#menu-btn');
    const leaveBtn = document.getElementById("leave-btn");
    const sideMenu = document.querySelector('.side-menu');

    const exitModal = document.querySelector('.exit-modal');

    leaveBtn.addEventListener("click", () => {
        exitModal.classList.add('visible');

        const cancel = exitModal.querySelector('#cancel');
        const confirm = exitModal.querySelector('#confirm');

        cancel.addEventListener('click', () => {
          exitModal.classList.remove('visible');
        })

        confirm.addEventListener('click', () => {
          exitModal.classList.remove('visible')
          loadHTML('../pages/index.html')
          window.location.reload();
        })
    });

    menuBtn.addEventListener('click', () => {
        sideMenu.classList.toggle('visible');
        menuBtn.classList.toggle('opened');
    })
}

form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})