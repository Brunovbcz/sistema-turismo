const username = 'a';
const password = 'a';

const form = document.querySelector('#login-form');

//Buttons
const menuBtn = document.querySelector('#menu-btn')

//Global Values
let clientsNumber = 0;

//Function to load html pages
function loadHTML(url, fn, targetId = 'html') {
  fetch(url)
    .then(res => {
      if (!res.ok) throw new Error(`Erro ao carregar ${url}`);
      return res.text();
    })
    .then(html => {
      document.querySelector(targetId).innerHTML = html;
      if (fn) fn()
    })
    .catch(err => {
      console.error(err);
      document.getElementById(targetId).innerHTML = '<p>Erro ao carregar conteúdo.</p>';
    });
}

function mainHeader(){
  const menuBtn = document.querySelector('#menu-btn');
  const leaveBtn = document.getElementById("leave-btn");
  const sideMenu = document.querySelector('.side-menu');
  const clientsBtn = document.querySelector('#clients');
  const dashBtn = document.querySelector('#dashboard');
  const employBtn = document.querySelector('#employes');
  const soldBtn = document.querySelector('#solds');
  const packsBtn = document.querySelector('#pack');

  const exitModal = document.querySelector('.exit-modal');

  leaveBtn.addEventListener("click", () => {
      exitModal.classList.add('visible');

      const cancel = exitModal.querySelector('#cancel');
      const confirm = exitModal.querySelector('#confirm');

      cancel.addEventListener('click', () => {
        exitModal.classList.remove('visible');
      })

      confirm.addEventListener('click', () => {
        exitModal.classList.remove('visible')
        loadHTML('../pages/index.html')
        window.location.reload();
      })
  });

  menuBtn.addEventListener('click', () => {
      sideMenu.classList.toggle('visible');
      menuBtn.classList.toggle('opened');
  })

  clientsBtn.addEventListener('click', () => {
    loadHTML('../pages/clientes.html', mainClients)
  })

  dashBtn.addEventListener('click', () => {
    loadHTML('../pages/dashboard.html', mainDashboard)
  })

  employBtn.addEventListener('click', () => {
    loadHTML('../pages/funcionarios.html', mainEmployes)
  })

  soldBtn.addEventListener('click', () => {
    loadHTML('../pages/vendas.html', mainSolds)
  })

  packsBtn.addEventListener('click', () => {
    loadHTML('../pages/pacotes.html', mainPacotes)
  })
}

function registrar(name, date, cpf, tel, email, tbody){
  let nameTh = document.createElement('th');
  let dateTh = document.createElement('th');
  let cpfTh = document.createElement('th');
  let telTh = document.createElement('th');
  let emailTh = document.createElement('th');

  nameTh.textContent = name;
  dateTh.textContent = date;
  cpfTh.textContent = cpf;
  telTh.textContent = tel;
  emailTh.textContent = email;

  let tr = document.createElement('tr');

  tr.appendChild(nameTh);
  tr.appendChild(dateTh);
  tr.appendChild(cpfTh);
  tr.appendChild(telTh);
  tr.appendChild(emailTh);

  tbody.appendChild(tr);
}

function mainEmployes(){


  mainHeader()
  let employTbody = document.querySelector('tbody');
  
  function registros(){
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);
    registrar('Matheus Cunha', '24/04/1998', '391.189.196-34', '(45) 98233-7042', 'matheus.cunha@gmail.com', employTbody);
    registrar('Ana Souza', '10/05/1995', '482.295.117-22', '(11) 93456-7890', 'ana.souza@email.com', employTbody);
    registrar('Lucas Oliveira', '17/08/1989', '294.581.903-10', '(21) 99876-5432', 'lucas.o@gmail.com', employTbody);
    registrar('Juliana Lima', '02/12/1992', '359.184.775-61', '(31) 98888-1122', 'juliana.lima@email.com', employTbody);
    registrar('Carlos Mendes', '29/09/1990', '125.963.841-00', '(85) 99777-3344', 'carlos.mendes@email.com', employTbody);

  }registros();
}

function mainSolds(){
  mainHeader();
}

function mainClients() {
  mainHeader();

  const cadastrarBtn = document.querySelector('#cad');
  const cadastrarPage = document.querySelector('.background-parent');
  const tbody = document.querySelector('tbody');

  exibirClientesSalvos(tbody);

  cadastrarBtn.addEventListener('click', () => {
    cadastrarPage.classList.add('visible');

    const cancel = cadastrarPage.querySelector('#cancel');
    const form = cadastrarPage.querySelector('form');
    const nameIn = cadastrarPage.querySelector('#name');
    const dateIn = cadastrarPage.querySelector('#date');
    const cpfIn = cadastrarPage.querySelector('#cpf');
    const telIn = cadastrarPage.querySelector('#tel');
    const emailIn = cadastrarPage.querySelector('#email');

    function handleSubmit(e) {
      e.preventDefault();
      cadastrarPage.classList.remove('visible');

      const cliente = {
        nome: nameIn.value,
        nascimento: dateIn.value,
        cpf: cpfIn.value,
        telefone: telIn.value,
        email: emailIn.value
      };

      salvarCliente(cliente);
      adicionarClienteNaTabela(cliente, tbody);

      form.removeEventListener('submit', handleSubmit);
      form.reset();
    }

    cpfIn.addEventListener('input', () => {
      let value = cpfIn.value.replace(/\D/g, '');
      value = value.slice(0, 11);
      if (value.length > 9) {
        value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
      } else if (value.length > 6) {
        value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
      } else if (value.length > 3) {
        value = value.replace(/(\d{3})(\d{1,3})/, '$1.$2');
      }
      cpfIn.value = value;
    });

    telIn.addEventListener('input', () => {
      let value = telIn.value.replace(/\D/g, '');
      value = value.slice(0, 11);
      if (value.length > 10) {
        value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
      } else if (value.length > 6) {
        value = value.replace(/(\d{2})(\d{4})(\d{1,4})/, '($1) $2-$3');
      } else if (value.length > 2) {
        value = value.replace(/(\d{2})(\d{1,5})/, '($1) $2');
      } else {
        value = value.replace(/(\d{0,2})/, '($1');
      }
      telIn.value = value;
    });

    cancel.addEventListener('click', () => {
      form.removeEventListener('submit', handleSubmit);
      cadastrarPage.classList.remove('visible');
    });

    form.addEventListener('submit', handleSubmit);
  });
}

function salvarCliente(cliente) {
  const clientes = JSON.parse(localStorage.getItem('clientes')) || [];
  clientes.push(cliente);
  localStorage.setItem('clientes', JSON.stringify(clientes));
  clientsNumber ++
  localStorage.setItem('quantidadeClientes', JSON.stringify(clientsNumber))
}

function exibirClientesSalvos(tbody) {
  //Corrigir
  let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
  clientes.forEach(cliente => {
    adicionarClienteNaTabela(cliente, tbody);
  });
}

function adicionarClienteNaTabela(cliente, tbody) {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${cliente.nome}</td>
    <td>${cliente.nascimento}</td>
    <td>${cliente.cpf}</td>
    <td>${cliente.telefone}</td>
    <td>${cliente.email}</td>
  `;
  tbody.appendChild(row);
}

function mainPacotes(){
  mainHeader();

  const btnNovoPacote = document.getElementById('cad');
  const btnExcluir = document.getElementById('ex');
  const modal = document.getElementById('new-package-modal');
  const overlay = document.getElementById('overlay');
  const btnCancelar = document.getElementById('cancel-btn');
  const btnConfirmar = document.getElementById('confirm-btn');

  const inputNome = document.getElementById('local-name');
  const inputImagem = document.getElementById('image-link');
  const inputDescricao = document.getElementById('description');
  const inputPreco = document.getElementById('price');

  const packsParent = document.querySelector('.packs-parent');

  const deleteListModal = document.getElementById('delete-list-modal');
  const deletePackList = document.getElementById('delete-pack-list');
  const btnCloseDeleteList = document.getElementById('btn-close-delete-list');

  const confirmDeleteModal = document.getElementById('confirm-delete-modal');
  const btnCancelDelete = document.getElementById('cancel-delete-btn');
  const btnConfirmDelete = document.getElementById('confirm-delete-btn');

  let pacoteSelecionado = null;

  function openModal(modalElement) {
    modalElement.classList.remove('hidden');
    overlay.classList.remove('hidden');
  }
  function closeModal(modalElement) {
    modalElement.classList.add('hidden');
    overlay.classList.add('hidden');
  }

  btnNovoPacote.addEventListener('click', () => {
    openModal(modal);
    inputNome.value = '';
    inputImagem.value = '';
    inputDescricao.value = '';
    inputPreco.value = '';
  });

  btnCancelar.addEventListener('click', () => closeModal(modal));
  overlay.addEventListener('click', () => {
    closeModal(modal);
    closeModal(deleteListModal);
    closeModal(confirmDeleteModal);
  });

  btnConfirmar.addEventListener('click', () => {
    const nome = inputNome.value.trim();
    const imagem = inputImagem.value.trim();
    const descricao = inputDescricao.value.trim();
    const preco = inputPreco.value.trim();

    if (!nome || !imagem || !descricao || !preco) {
      return;
    }
    if (isNaN(preco) || Number(preco) < 0) {
      return;
    }

    const novoPack = document.createElement('div');
    novoPack.classList.add('pack-container');

    novoPack.innerHTML = `
      <img src="${imagem}" alt="Imagem de ${nome}" onerror="this.src='https://via.placeholder.com/450x280?text=Imagem+inválida'">
      <h2>${nome}</h2>
      <p><strong>Custo (individual):</strong> R$ ${Number(preco).toFixed(2)}</p>
      <p><strong>Descrição: </strong>${descricao}</p>
    `;

    packsParent.appendChild(novoPack);
    closeModal(modal);
  });

  btnExcluir.addEventListener('click', () => {
    deletePackList.innerHTML = '';

    const pacotes = packsParent.querySelectorAll('.pack-container');
    if(pacotes.length === 0){
      alert("Não há pacotes para excluir.");
      return;
    }

    pacotes.forEach((pack, index) => {
      const nomePacote = pack.querySelector('h2').textContent;
      const li = document.createElement('li');
      li.textContent = nomePacote;
      li.style.cursor = 'pointer';
      li.style.padding = '8px 12px';
      li.style.borderBottom = '1px solid #ccc';

      li.addEventListener('click', () => {
        pacoteSelecionado = pack;
        closeModal(deleteListModal);
        openModal(confirmDeleteModal);
      });

      deletePackList.appendChild(li);
    });

    openModal(deleteListModal);
  });

  btnCloseDeleteList.addEventListener('click', () => {
    closeModal(deleteListModal);
  });

  btnCancelDelete.addEventListener('click', () => {
    closeModal(confirmDeleteModal);
    pacoteSelecionado = null;
  });

  btnConfirmDelete.addEventListener('click', () => {
    if(pacoteSelecionado){
      packsParent.removeChild(pacoteSelecionado);
      pacoteSelecionado = null;
    }
    closeModal(confirmDeleteModal);
  });
}

function mainDashboard(){
    mainHeader()

  clientsNumber = localStorage.getItem('quantidadeClientes');
  if (clientsNumber === 'undefined') clientsNumber = 0;
  document.getElementById("vendas-7d").innerText = "R$ 0,00";
  document.getElementById("vendas-30d").innerText = "R$ 0,00";
  document.getElementById("clientes").innerText = clientsNumber;
}

form.addEventListener('submit', (e) => {
    e.preventDefault()

    let usertext = document.querySelector('.user').querySelector('input');
    let passtext = document.querySelector('.password').querySelector('input');
    
    if (usertext.value === username && passtext.value === password){
        loadHTML('../pages/dashboard.html', mainDashboard);
    }
    else{
        let errorText = document.createElement('h2');
        document.querySelector('#error-message').textContent = 'Usuário ou senha incorretos.'
    }
})